Phase VI.1 artifacts: verifier outputs, ORD compressed metrics, and QMP pricing streams with audit checksums.
Run locally: scripts/run_phase_vi1_local.sh
