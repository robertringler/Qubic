# Automation Run Summary
*Config hash*: `64ef932f5be16aa9`  
*Tasks*: 1  
*Failures*: False  
*Aggregate CPU (s)*: 5.48
*Aggregate Wall (s)*: 6.94
*Throughput (tasks/s)*: 0.144
*Peak RSS (bytes)*: 100851712
*D2 coverage*: 1/1 (100.0%) | genuine=1 forced=0
*Forced D2 fraction*: 0.00 (gate_ok=True)
*Logical fidelity*: mean=0.643 min=0.643 gate_ok=True
