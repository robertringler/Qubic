#!/usr/bin/env python3
"""
Toy variational MPS algorithm to approximate ground states and compute half-chain entanglement
for a nearest+long-range hopping model. This is intentionally lightweight and educational.
"""
import numpy as np
import os
import scipy.linalg as la
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def build_lr_hamiltonian(N, t1=1.0, alpha=1.2):
    H = np.zeros((N,N))
    for i in range(N):
        for j in range(N):
            if i==j: continue
            r = abs(i-j)
            H[i,j] = -t1/(r**alpha)
    return H

def free_fermion_entropy(H):
    # diagonalize and compute correlation matrix at half-filling
    eps, U = la.eigh(H)
    N = H.shape[0]
    nocc = N//2
    C = U[:,:nocc] @ U[:,:nocc].T
    # half-chain entropy
    Csub = C[:N//2,:N//2]
    vals = la.eigvalsh(Csub)
    vals = np.clip(vals, 1e-12, 1-1e-12)
    S = -np.sum(vals*np.log(vals) + (1-vals)*np.log(1-vals))
    return S

def sweep_system_sizes(sizes=[64,128,256,512], alphas=[0.8,1.2,1.8]):
    results = {}
    for a in alphas:
        Ss = []
        for N in sizes:
            H = build_lr_hamiltonian(N, alpha=a)
            S = free_fermion_entropy(H)
            Ss.append(S)
            print(f'alpha={a} N={N} S={S:.4f}')
        results[a] = (sizes, Ss)
    return results

def plot_results(results, outdir='figures'):
    os.makedirs(outdir, exist_ok=True)
    plt.figure(figsize=(8,4))
    for a, (sizes, Ss) in results.items():
        plt.loglog(sizes, Ss, marker='o', label=f'alpha={a}')
    plt.xlabel('System size N')
    plt.ylabel('Half-chain entanglement entropy S')
    plt.legend()
    plt.tight_layout()
    outpdf = os.path.join(os.path.dirname(__file__), '..', 'figures', 'fig_mps_entropy.pdf')
    outpng = outpdf.replace('.pdf', '.png')
    plt.savefig(outpdf)
    plt.savefig(outpng, dpi=300)
    print('Wrote', outpdf, outpng)

if __name__=='__main__':
    results = sweep_system_sizes(sizes=[64,128,256,512], alphas=[0.8,1.2,1.8])
    plot_results(results)
