Reproducibility for manuscript simulations

Quick start (Windows cmd.exe):

1. Create and activate a virtual environment (optional but recommended):
   python -m venv .venv
   .\.venv\Scripts\activate

2. Install dependencies:
   pip install -r requirements.txt

3. Run the smoke test to generate a quick figure:
   run_smoke_test.bat

Files:
- `smoke_test.py`: small, fast simulation that produces `smoke_test_output.png`.
- `requirements.txt`: minimal python dependencies.
- `run_smoke_test.bat`: batch wrapper to run the smoke test on Windows.
