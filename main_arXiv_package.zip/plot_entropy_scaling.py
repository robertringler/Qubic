#!/usr/bin/env python3
"""
Generate example entropy scaling plots for the Anti-holographic Entangled Universe manuscript.
Produces `entropy_scaling.png` and `entropy_scaling.pdf` in the same folder.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def simulate_entropy(linspace, gamma, chi0=64, eta=0.7):
    # Toy model: entropy ~ sum_{s<=s*} 2^{-sd} s^{kappa-gamma} -> approximate power-law
    # We'll produce a smooth curve with exponent depending on gamma
    alpha_base = 1/3.0
    alpha = alpha_base + 0.5 * (gamma / 1.5)
    return (linspace**(alpha)) * (1.0 + 0.1*np.random.randn(len(linspace)))

def main():
    L = np.logspace(0, 3, 50)
    gammas = [0.0, 0.5, 1.0]

    plt.figure(figsize=(6,4))
    for g in gammas:
        S = simulate_entropy(L, g)
        plt.loglog(L, np.abs(S), marker='o', label=f'gamma={g}')

    plt.xlabel('Region linear size $\ell$')
    plt.ylabel('Entanglement entropy $S(\ell)$')
    plt.title('Toy entropy scaling for branching exponents')
    plt.legend()
    plt.grid(True, which='both', ls='--', alpha=0.5)
    plt.tight_layout()
    outpng = 'entropy_scaling.png'
    outpdf = 'entropy_scaling.pdf'
    plt.savefig(outpng, dpi=300)
    plt.savefig(outpdf)
    print('Wrote', outpng, outpdf)

if __name__=='__main__':
    main()
