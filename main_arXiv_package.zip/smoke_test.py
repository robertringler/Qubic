"""Quick smoke test for manuscript simulations.

Generates a small synthetic dataset and writes `smoke_test_output.png` into the
simulations directory. Designed to run quickly (<< 30s) and verify the
environment/dependencies.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def run_smoke_test(out_path="smoke_test_output.png"):
    # simple damped oscillation example used in several figures
    t = np.linspace(0, 10, 500)
    y = np.exp(-0.2 * t) * np.cos(2.0 * np.pi * 0.7 * t)

    plt.figure(figsize=(4, 3))
    plt.plot(t, y, lw=1)
    plt.xlabel("time")
    plt.ylabel("amplitude")
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    run_smoke_test()
