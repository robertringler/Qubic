#!/usr/bin/env python3
"""
Compute ground-state entanglement entropy for a 1D free-fermion chain with power-law hopping.
Outputs an entropy scaling plot `fig_longrange_entropy.pdf` in the manuscript/figures folder.

This is a simple, efficient calculation using correlation-matrix methods for free fermions.
"""
import numpy as np
import scipy.linalg as la
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def build_hopping(N, alpha):
    # Hopping t_r ~ 1/r^{alpha}
    H = np.zeros((N,N), dtype=float)
    for i in range(N):
        for j in range(N):
            if i!=j:
                r = min(abs(i-j), N-abs(i-j))
                H[i,j] = 1.0/(r**alpha)
    return H

def ground_state_correlation(H, fill=0.5):
    # diagonalize H: we take single-particle eigenvectors
    eps, U = la.eigh(H)
    # fill lowest N/2 states (half-filling)
    N = H.shape[0]
    nocc = N//2
    C = U[:,:nocc] @ U[:,:nocc].conj().T
    return C.real

def entanglement_entropy(Csub):
    # eigenvalues of correlation matrix restricted to subsystem
    vals = la.eigvalsh(Csub)
    # clamp
    vals = np.clip(vals, 1e-12, 1-1e-12)
    S = -np.sum(vals*np.log(vals) + (1-vals)*np.log(1-vals))
    return S

def run_experiment(N=512, alphas=[1.5,1.0,0.7], outdir='figures'):
    os.makedirs(outdir, exist_ok=True)
    Ls = np.arange(4, N//4, 4)
    plt.figure(figsize=(6,4))
    for a in alphas:
        H = build_hopping(N, a)
        C = ground_state_correlation(H)
        Ss = []
        for L in Ls:
            Csub = C[:L,:L]
            Ss.append(entanglement_entropy(Csub))
        plt.loglog(Ls, Ss, marker='o', label=f'alpha={a}')
    plt.xlabel('Subsystem size L')
    plt.ylabel('Entanglement entropy S(L)')
    plt.legend()
    plt.tight_layout()
    outpdf = os.path.join(os.path.dirname(__file__), '..', 'figures', 'fig_longrange_entropy.pdf')
    outpng = outpdf.replace('.pdf', '.png')
    plt.savefig(outpdf)
    plt.savefig(outpng, dpi=300)
    print('Wrote', outpdf, outpng)

if __name__=='__main__':
    run_experiment(N=512, alphas=[1.8,1.2,0.8])
